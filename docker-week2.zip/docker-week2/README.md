Peer Reviewer - Rahul Kumar

#  Docker Multi-Service Project

This project demonstrates containerization of multiple services using Docker:

1. Test Automation Framework (Playwright)
2. API Service
3. Static Website

The goal of this project is to apply Docker best practices, optimize image sizes, and ensure clean container lifecycle management.

---

## Prerequisites

- Docker installed
- Node project configured
- Basic understanding of Docker concepts

Verify Docker installation:

```bash
docker --version
```

---

#  Services Overview

| Service            | Image Name              | Port  | Mode        | Target Size |
|--------------------|------------------------|-------|-------------|------------|
| Test Automation    | playwright-tests:1.0   | N/A   | Run & Exit  | < 2GB      |
| API Service        | api-service:1.0        | 3000  | Detached    | < 300MB    |
| Static Website     | static-website:1.0     | 8080  | Detached    | < 50MB     |

---

#  How to Build the Images

Refer to `BUILD_COMMANDS.md` for detailed build steps.

### Example:

## Test Automation

```bash
cd test-automation
docker build -t playwright-tests:1.0 .
```

## API Service

```bash
cd api-service
docker build -t api-service:1.0 .
```

##  Static Website

```bash
cd static-website
docker build -t static-website:1.0 .
```

---

# ️ How to Run the Containers

### Test Automation

```bash
docker run --rm playwright-tests:1.0
```
- Runs tests
- Automatically removes container after completion

### API Service

```bash
docker run -d -p 3000:3000 --name api-service api-service:1.0
```

Access:
```
http://localhost:3000
```

### Static Website

```bash
docker run -d -p 8080:80 --name static-web static-website:1.0
```

Access:
```
http://localhost:8080
```

---

# Port Mappings

| Container Port | Host Port | Purpose |
|---------------|-----------|----------|
| 3000          | 3000      | API Service |
| 80            | 8080      | Static Website |

Example:

```bash
-p 3000:3000
```

Format:
```
-p <host_port>:<container_port>
```

This allows accessing container services from your local machine.

---

#  Environment Variables

If environment variables are required, use:

```bash
docker run -e NODE_ENV=production api-service:1.0
```

Or multiple variables:

```bash
docker run -e NODE_ENV=production -e PORT=3000 api-service:1.0
```

Environment variables allow:

- Configuration without modifying code
- Secure runtime customization
- Production-ready deployment

---

#  Verification

After running services:

```bash
docker ps
```

Check image size:

```bash
docker images
```

Ensure:
- Containers are running
- Ports are mapped correctly
- Applications are accessible in browser
- Image sizes meet target limits

---

#  Stop & Remove Containers

```bash
docker stop api-service static-web
docker rm api-service static-web
```

---

#  Troubleshooting

## Port Already in Use

Error:
```
Bind for 0.0.0.0:3000 failed
```

Solution:
- Stop existing service using the port
- Or change host port:

```bash
docker run -d -p 4000:3000 api-service:1.0
```

---

## Container Not Running

Check logs:

```bash
docker logs api-service
```

---

## Image Too Large

Check:

```bash
docker images
```

Possible causes:
- Missing `.dockerignore`
- Installing dev dependencies
- Large base image

---

## Tests Not Running

Ensure:

- Docker build completed successfully
- Internet connection available for browser dependencies
- Correct working directory used before build

---

# Technologies Used

- Docker
- Node.js
- Playwright
- Nginx (Static Website)
- REST API Service

---

#  Learning Outcomes

Through this project:

- Understood Docker image layering
- Learned container lifecycle management
- Practiced image optimization
- Implemented multi-service containerization
- Applied real-world Docker best practices

---

#  Conclusion

This project demonstrates a structured and production-oriented approach to containerizing:

- Automated test frameworks
- Backend services
- Static frontend applications

The implementation follows industry-standard Docker practices suitable for scalable deployments.

---
