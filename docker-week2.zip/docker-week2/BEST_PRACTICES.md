# Docker Best Practices Used

This document outlines best practices followed while building and running Docker images for:

- Test Automation (Playwright)
- API Service
- Static Website

---

# 1. Layer Caching Strategy

Docker builds images in layers. Proper layer ordering significantly improves build performance.

## Strategy Followed

- Copied `package.json` first
- Installed dependencies before copying full source code
- Copied application source after dependencies
- Avoided unnecessary layer invalidation

### Example Approach

```
COPY package*.json ./
RUN npm ci --only=production
COPY . .
```

## Why This Matters

- Prevents reinstalling dependencies on every build
- Speeds up rebuild time
- Reduces development friction
- Improves CI/CD performance

---

# 2. Security Practices

Security was considered during image creation and runtime configuration.

##  Official Base Images

- Used official Microsoft Playwright image
- Avoided unofficial or unknown Docker images

Example:
```dockerfile
FROM mcr.microsoft.com/playwright:v1.40.0-focal
```

---

##  Production Mode

- Used production-ready dependency installation
- Avoided installing unnecessary development packages

Example:
```bash
npm ci --only=production
```

---

##  Use Explicit Port Mapping

```bash
-p 3000:3000
-p 8080:80
```

Benefits:
- Clear network exposure
- Easier debugging
- Avoids port conflicts

---

##  Clean Container Lifecycle

- Used `--rm` for temporary containers
- Stopped and removed containers properly

---

# 3. Optimization Techniques

##  Use Detached Mode for Services

For long-running services:

```bash
docker run -d -p 3000:3000 --name api-service api-service:1.0
docker run -d -p 8080:80 --name static-web static-website:1.0
```

Benefits:
- Runs in background
- Keeps terminal free
- Suitable for production-like setup

---

##  Build from Service Directory

Each service is built from its own directory:

```bash
cd test-automation
cd api-service
cd static-website
```

Benefits:
- Keeps builds isolated
- Improves maintainability
- Follows microservice structure

---

##  Use Named Containers

```bash
--name api-service
--name static-web
```

Benefits:
- Easier container management
- Simple stop/remove commands
- Cleaner `docker ps` output

---

##  Used `npm ci` Instead of `npm install`

Benefits:
- Faster installation
- Deterministic dependency resolution
- Ideal for CI/CD

---

##  Used `--only=production`

- Installed only required dependencies
- Reduced final image size
- Removed unnecessary dev packages

---

##  Implemented `.dockerignore`

Ignored unnecessary files such as:

- `node_modules`
- `.git`
- local artifacts
- logs
- test results

Benefits:
- Smaller image
- Faster build
- Reduced attack surface

---

##  Avoided Copying `node_modules`

- Prevented host environment conflicts
- Ensured clean dependency installation inside container

---


# 4. Mistakes Avoided

Several common Docker mistakes were consciously avoided.

##  Copying Entire Project Before Installing Dependencies

This would invalidate caching on every code change.

---

## Running `npm install` Twice

Avoided redundant dependency installation which increases image size and build time.

---

## Using `latest` Tag for Base Images

Avoided unstable builds by not using:

```
FROM node:latest
```

Used version-specific images instead for stability and reproducibility.

---

## Leaving Unused Containers Running

Used proper stop and remove commands to avoid container clutter.

---

# 5.  Lessons Learned

## Image Size Depends on Base Image

The base image contributes most to final size. Choosing the right base image is critical.

---

## Layer Order Affects Build Speed

- Changing source code should not trigger dependency reinstall.
- Proper layer separation drastically improves rebuild performance.

---

##  `.dockerignore` Is Critical

Without `.dockerignore`:
- Image size increases
- Build time increases
- Sensitive files may get copied

---

## Container Lifecycle Management Is Important

- Temporary workloads should use `--rm`
- Long-running services should use detached mode
- Containers must be stopped and removed cleanly

---

## Optimization Is Iterative

Improving image size and build speed requires:
- Observing image layers
- Measuring build time
- Adjusting Dockerfile structure

---

#  Summary

Following these best practices ensures:

-  Smaller images
-  Faster builds
-  Better security
-  Predictable deployments
-  Clean container management
-  Production-ready Docker setup

---

#  Conclusion

Applying Docker best practices improves:

- Performance
- Maintainability
- Security
- Scalability

This project follows industry-standard containerization principles suitable for real-world deployment.

---
