# Docker Build & Run Guide

This document explains how to build, verify, and run all project Docker images.

---

#  Build Commands

---

## 1. Test Automation Framework


###  Navigate to Service

```bash
cd test-automation
```

###  Build Image

```bash
cd test-automation
docker build -t playwright-tests .
```

---

### Check Image Size

```bash
docker images playwright-tests
```

**Expected Size:** `< 2GB`
**Current Size:** `~2.8GB` 

The image size exceeds 2GB because Playwright installs multiple browser engines (Chromium, Firefox, and WebKit) along with their system dependencies. Each browser significantly increases the image size. Additionally, the base Playwright image itself includes debugging tools and full OS libraries, contributing to the total disk usage.
Also The Base Image Is Already Very Large.
---

###  Run Container

```bash
docker run --rm playwright-tests
```

The test is failing due to a version mismatch between the Playwright package installed via npm (v1.58.2) and the Docker base image (v1.40.0). Since Playwright tightly couples browser binaries to its version, the newer Playwright expects updated browser executables that are not available in the older Docker image. This causes the browser launch to fail.

---

###  Verification Steps

1. Docker image builds successfully
2. Container runs without errors
3. Playwright browser launches correctly
4. All test cases execute
5. `test-results/` folder is generated
6. Validate image size is under 2GB

---

## 2. API Service

### Navigate to Service

```bash
cd api-service
```

###  Build Image

```bash
cd api-service
docker build -t api-service:1.0 .
```

---

###  Check Image Size

```bash
docker images api-service:1.0
```

**Expected Size:** `< 300MB`

---

###  Run Container

```bash
docker run -d -p 3000:3000 --name api-service api-service:1.0
```

Access the API at:

```
http://localhost:3000
```

---


###  Verification Steps – API Service

1. Docker image builds successfully
2. Container runs without errors in detached mode.
3. Port 3000 is exposed properly
4. API responds in browser or Postman
5. No container crashes (`docker ps` shows running)
6. Image size is under 300MB

You can verify container status using:

```bash
docker ps
```

---

## 3. Static Website


### Navigate to Service

```bash
cd static-website
```
###  Build Image

```bash
cd static-website
docker build -t static-website:1.0 .
```

---

###  Check Image Size

```bash
docker images static-website:1.0
```

**Expected Size:** `< 50MB`

---

###  Run Container

```bash
docker run -d -p 8080:80 --name static-web static-website:1.0
```

Access the website at:

```
http://localhost:8080
```

---

### Verification Steps – Static Website

1. Docker image builds successfully
2. Container runs without errors in detached mode.
3. Port 8080 is exposed properly
4. Website loads in browser
5. Static assets (CSS/JS/images) load properly
6. Image size is under 50MB

You can verify container status using:

```bash
docker ps
```

---


#  Optional: Stop & Remove Containers

```bash
docker stop api-service static-web
docker rm api-service static-web
```

---

#  Summary

| Service            | Image Name              | Port  | Mode        |
|--------------------|------------------------|-------|-------------|
| Test Automation    | playwright-tests:1.0   | N/A   | Run & Exit  |
| API Service        | api-service:1.0        | 3000  | Detached    |
| Static Website     | static-website:1.0     | 8080  | Detached    |

---
