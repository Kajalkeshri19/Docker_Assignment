# Image Analysis

## Inspect Image

docker inspect playwright-tests
![test_automation_inspect.png](test_automation_inspect.png)

docker inspect api-service:1.0
![api_service_inspect.png](api_service_inspect.png)

docker inspect static-website:1.0
![static_website_inspect.png](static_website_inspect.png)


## View Layer History

docker history playwright-tests
![test_automation_history.png](test_automation_history.png)

docker history api-service:1.0
![api_service_history.png](api_service_history.png)

docker history static-website:1.0
![static_website_history.png](static_website_history.png)

## Size Analysis

![images_size.png](images_size.png)

Test-Automation Image Size Breakdown:
![Test_Automation_layers_breakdown.png](Test_Automation_layers_breakdown.png)

Api Service Image Size Breakdown:
![api_Service_layers.png](api_Service_layers.png)

Static Website Image Size Breakdown:
![static_website_layers.png](static_website_layers.png)

| Image                       | Size (Actual) | Target Size | Status          | Notes                                                                               |
| --------------------------- | ------------- | ----------- | --------------- |-------------------------------------------------------------------------------------|
| **playwright-tests:latest** | 2.78 GB       | < 2 GB      | ️ Exceeds target | Base Image is of large Size.                                                        |
| **api-service:1.0**         | 187 MB        | < 300 MB    |  Pass           | Well within target. Alpine base keeps image small.                                  |
| **static-website:1.0**      | 73.7 MB       | < 50 MB     | ⚠ Exceeds target | Image exceeds 50 MB mostly due to the full nginx installation and required modules. |

